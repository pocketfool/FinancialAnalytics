/**
* @mainpage
* Qtstalker http://qtstalker.sourceforge.net/
*
* This source code documentation is generated on an irregular basis directly
* from the CVS source code. Every component is listed, but not yet all properly
* documented.
*
* Start at <a href="class_qtstalker_app.html">QtstalkerApp Class Reference</a>
* and <a href="class_indicator_plugin.html">IndicatorPlugin Class Reference</a>
* and <a href="inherits.html">Graphical Class Hierarchy</a>.
*
* \todo
* See main <a href="http://qtstalker.cvs.sourceforge.net/qtstalker/qtstalker/docs/TODO">todo</a> list
* and <a href="todo.html">todo</a> list generated from the source code.
* See <a href="http://sourceforge.net/tracker/?group_id=25632&atid=384883">Issue Tracker</a>
* and <a href="http://sourceforge.net/tracker/?group_id=25632&atid=384886">Feature Requests</a>.
* Note that none of these lists are complete.
*/

