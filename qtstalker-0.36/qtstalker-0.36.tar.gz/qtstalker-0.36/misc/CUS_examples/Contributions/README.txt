Each contributor has their own space.

See http://qtstalker.sf.net/cvs-contrib.html
