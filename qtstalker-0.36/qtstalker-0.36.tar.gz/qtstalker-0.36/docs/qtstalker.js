window.onload = function() {
 var oDiv = document.getElementById("version");
 oDiv.innerHTML = "Version 0.36<br />(other <a href='faq.html#versions'>versions</a>)";
}
