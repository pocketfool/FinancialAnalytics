<!DOCTYPE TS><TS>
<context>
    <name>BarEdit</name>
    <message>
        <source>Delete Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete record.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete record?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Record has been modified.
Save changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last Record</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BuyArrow</name>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit BuyArrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select point to place BuyArrow...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CME</name>
    <message>
        <source>Downloading </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Timeout: retry limit skipping file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Timeout: retry </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>could not open parse history file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to create futures directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CME Prefs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>COBase</name>
    <message>
        <source>&amp;Edit Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete Object</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CSV</name>
    <message>
        <source>Delimiter not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No rule found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Directory not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule missing Date field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to create directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bad date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bad time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bad value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Date Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter new rule name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NewRule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This rule already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Rule To Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Rules To Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete this rule?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File fields != rule format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CSV Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CSVRuleDialog</name>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editing CSV Rule: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chart Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delimiter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Semicolon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data Directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol Filter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Must inlcude a directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No spaces allowed in directory name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid directory name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disk Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot save file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot read file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CUSDialog</name>
    <message>
        <source>CUS Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChartPage</name>
    <message>
        <source>List Filter, e.g. s* or sb*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit Chart<byte value="x9"/>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete Chart<byte value="x9"/>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E&amp;xport Chart CSV<byte value="x9"/>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D&amp;ump Chart<byte value="x9"/><byte value="x9"/>Ctrl+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help<byte value="x9"/>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Charts To Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete selected charts?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Charts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add To &amp;Group<byte value="x9"/>Ctrl+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete selected chart?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChartToolbar</name>
    <message>
        <source>Bar Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bar Spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total bars to load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paper Trade Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Next Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pan Chart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paper trade date select.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Weekly Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Daily Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>15min Compression</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Cycle</name>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Cycle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select starting point of Cycle...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DataWindow</name>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExScript</name>
    <message>
        <source>ExScript Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Script timeout. Cancel process?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FG</name>
    <message>
        <source>Timeout: retry limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Timeout: retry </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FG Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cant write to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bad date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to create futures directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open db</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FiboLine</name>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit FiboLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Levels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select FiboLine high point...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select FiboLine low point...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileButton</name>
    <message>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FontButton</name>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormulaEdit</name>
    <message>
        <source>Open Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Formula</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select rule to open.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate variable name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Include Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select rule to include</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FuturesDialog</name>
    <message>
        <source>Qtstalker: Edit Futures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Futures Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Futures Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Record has been modified.
Save changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exchange</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GroupPage</name>
    <message>
        <source>Current Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New Group<byte value="x9"/><byte value="x9"/>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Add Group Items<byte value="x9"/>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete Group Items<byte value="x9"/>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>De&amp;lete Group<byte value="x9"/>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Rename Group<byte value="x9"/>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help<byte value="x9"/><byte value="x9"/>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter new group symbol.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NewGroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This group already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Group Items To Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete group items?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete current group </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This chart group exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group rename failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete group item?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HelpWindow</name>
    <message>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HorizontalLine</name>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit HorizontalLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select point to place HorizontalLine...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IndexDialog</name>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Index Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Index Item</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IndicatorPage</name>
    <message>
        <source>Indicator Groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List Filter, e.g. s* or sb*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New Indicator Group<byte value="x9"/><byte value="x9"/>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Indicator Group<byte value="x9"/>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ne&amp;w Indicator<byte value="x9"/><byte value="x9"/>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit Indicator<byte value="x9"/><byte value="x9"/><byte value="x9"/>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete Indicator<byte value="x9"/><byte value="x9"/>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mo&amp;ve Indicator<byte value="x9"/><byte value="x9"/>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help<byte value="x9"/><byte value="x9"/><byte value="x9"/>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Indicator Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter new group symbol.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NewGroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This group already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Indicator Group(s) To Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete indicator group items?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Delete Indicator Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot delete default group.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tab Row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicator Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NewIndicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicator name missing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate indicator name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to permanently delete this indicator?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Add Local Indicator<byte value="x9"/><byte value="x9"/>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Local Indicator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IndicatorPlot</name>
    <message>
        <source>Creating chart snapshot...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing complete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New &amp;Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Chart Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete &amp;All Chart Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Print Chart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Scaling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Delete All Chart Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No chart objects to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit &amp;Chart</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IndicatorSummary</name>
    <message>
        <source>Qtstalker: Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No files in group.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainMenubar</name>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit Qtstalker (Ctrl+1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New &amp;Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add a new indicator to chart (Ctrl+2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit &amp;Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modify user preferences  (Ctrl+3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chart &amp;Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle the chart grid  (Ctrl+4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download quotes from internet  (Ctrl+Q)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Data Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show the data window (Alt+1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About Qtstalker.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Scale To Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale chart to current screen data (Ctrl+5)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Side Pa&amp;nel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle the side panel area from view (Ctrl+7)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Dra&amp;w Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle drawing mode (Ctrl+0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Cross&amp;hairs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle crosshairs (Ctrl+6)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paper Trade Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle the paper trade mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display Help Dialog (Alt+3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicator Summary</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NYBOT</name>
    <message>
        <source>Timeout: retry limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Timeout: retry </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NYBOT Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cant write to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bad date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to create futures directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open db</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update cancelled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NavigatorTab</name>
    <message>
        <source>Workwith Charts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workwith Groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Main Chart Indicators</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workwith Portfolios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workwith Backtesting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workwith Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Navigator Position</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PortfolioDialog</name>
    <message>
        <source>Qtstalker: Portfolio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L/S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Buy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profit%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balance: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Portfolio Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No symbol selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Portfolio Item</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PortfolioPage</name>
    <message>
        <source>&amp;New Portfolio<byte value="x9"/>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open Portfolio<byte value="x9"/><byte value="x9"/>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete Portfolio<byte value="x9"/>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Rename Portfolio<byte value="x9"/>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help<byte value="x9"/><byte value="x9"/>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Portfolio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter new portfolio name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NewPortfolio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This portfolio already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Portfolios To Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete this portfolio?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Portfolio</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrefDialog</name>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <source>Edit Prefs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Main Menubar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bar Spacing 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bar Spacing 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bar Spacing 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chart Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chart Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chart Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plot Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>App Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Side Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale to Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CrossHair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PaperTrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DrawMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NewIndicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DataWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MainQuote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MainToolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BarsToLoad Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BarSpacing Spinner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cmps.15Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cmps.Daily</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cmps.Weekly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cmps.ComboBox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ChartToolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OpenInterest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DayOfWeek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DayofWeek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5 Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10 Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>15 Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>30 Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>60 Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Daily</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Futures Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gapless</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New CC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not create ~/.qtstalker/data/CC directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit CC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Disk Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Australian Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Soybean Oil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>British Pound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Corn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cocoa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Canadian Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crude Oil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CRB Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cotton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dow Jones Industrial Average</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>US Dollar Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Euro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eurodollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-MINI S&amp;P 500</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Feeder Cattle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goldman Sachs Commodity Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Heating Oil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unleaded Gasoline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frozen Concentrated Orange Juice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Japanese Yen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coffee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lumber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Live Cattle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lean Hogs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NASDAQ 100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Natural Gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-MINI NASDAQ 100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Palladium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frozen Pork Bellies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Platinum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Soybeans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sugar #11 World</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swiss Franc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Silver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Soy Meal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;P 500</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Treasury Note 10 yr.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>US Treasury Bond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wheat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NYSE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WIG20 Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter symbol name for the new Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not create ~/.qtstalker/data/Index directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Index already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Histogram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Histogram Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invisible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Candle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download error: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Spread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter symbol name for the new Spread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not create Spread directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Spread already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot create chart.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit Short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max Loss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trailing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CUS Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Second Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BARS type Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a bar type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Neutral Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Candle Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA Line Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA Period</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA2 Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA2 Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA2 Line Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA2 Period</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA2 Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA2 Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA3 Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA3 Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA3 Line Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA3 Period</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA3 Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA3 Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BARS Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Period</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smoothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smoothing Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FI Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SlowK Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 Day prediction Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5 Day Prediction Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line Type K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line Type 2 Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line Type 5 Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show 2 Day Prediction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show 5 Day Prediction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fast K Period</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slow K Period</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plot Test Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LMS Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Freq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LOWPASS Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PP FS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PP SS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PP TS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PP FR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PP SR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PP TR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Support Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label First Support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label Second Support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label Third Support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resistance Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label First Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label Second Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label Third Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PP Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sine Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lead Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sine Line Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lead Line Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SINWAV Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SZ LONG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SZ SHORT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lookback Period</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Decline Period</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coefficient</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SZ Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select an indicator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TALIB Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>THERM MA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>THERM Parms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MA Parms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color Above MA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color Below MA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color Threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>THERM Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VFI Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vidya period</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volatility Period</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VIDYA Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VOL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VOL Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VOL Line Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VOL Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicator Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Spread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BARS Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FI Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LMS Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LOWPASS Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PP Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PP Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SINWAV Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SYMBOL Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SZ Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TALIB Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>THERM Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UTIL Indicator Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Array Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Array Input2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color Array</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Constant Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Operator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UTIL Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VFI Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VIDYA Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VOL Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BARS Method Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a method:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Script Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ExScript Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ExScript Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicator Summary Parms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicator Summary - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add To Group Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Interest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Timeout Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Min Array</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max Array</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continuous Adjusted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>O Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reversal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Box Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bar Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Candle Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&amp;F Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disk error, cannot create chart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Buenos Aires Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vienna Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Australian Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sao Paolo Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toronto Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TSX Venture Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shanghai Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shenzhen Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copenhagen Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paris Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Berlin Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bremen Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dusseldorf Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frankfurt Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hamburg Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hanover Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Munich Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stuttgart Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XETRA Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hong Kong Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bombay Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>National Stock Exchange of India</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jakarta Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tel Aviv Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Milan Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Korea Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>KOSDAQ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mexico Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amsterdam Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Zealand Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oslo Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Singapore Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barcelona Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bilbao Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Madrid Fixed Income Market</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Madrid SE C.A.T.S.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Madrid Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stockholm Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swiss Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Taiwan OTC Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Taiwan Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>London Stock Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down Candle Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Candle Fill When</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtstalkerApp</name>
    <message>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About Qtstalker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading chart...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading indicators...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading chart objects...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quote Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Quote Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker
Ver CVS 0.34 (working title)
(C) 2001-2006 by Stefan Stratigakos</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QuotePlugin</name>
    <message>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update cancelled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Canceled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Timeout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Updating ...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scanner</name>
    <message>
        <source>Symbol Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All symbols</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0 Symbols</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bar Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No symbols selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scanning...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select symbols to scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerPage</name>
    <message>
        <source>List Filter, e.g. s* or sb*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New Scanner<byte value="x9"/><byte value="x9"/>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open Scanner<byte value="x9"/><byte value="x9"/>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete Scanner<byte value="x9"/>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Rename Scanner<byte value="x9"/><byte value="x9"/>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R&amp;un Scanner<byte value="x9"/><byte value="x9"/>Ctrl+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help<byte value="x9"/><byte value="x9"/>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select scanners to run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter new scanner name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NewScanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This scanner already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Scanners To Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete this scanner?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Scanner</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SellArrow</name>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit SellArrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select point to place SellArrow...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Price</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpreadDialog</name>
    <message>
        <source>Spread Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Second Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StocksDialog</name>
    <message>
        <source>Qtstalker: Edit Stock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fundamentals: last updated </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No data available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Split Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Split Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Perform Split</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Split</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Record has been modified.
Save changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want split the stock?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid split date.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid split ratio format.
eg. 2:1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Split Complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fundamentals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exchange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Split complete.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SymbolButton</name>
    <message>
        <source>Select Symbol</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TestPage</name>
    <message>
        <source>List Filter, e.g. s* or sb*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New Rule<byte value="x9"/><byte value="x9"/>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open Rule<byte value="x9"/><byte value="x9"/>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete Rule<byte value="x9"/>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Rename Rule<byte value="x9"/><byte value="x9"/>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Copy Rule<byte value="x9"/><byte value="x9"/>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help<byte value="x9"/><byte value="x9"/>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Backtest rule To Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete backtest rule?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Backtest Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter new backtest rule name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This backtest rule already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy Backtest Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter new name of copy.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Tester</name>
    <message>
        <source>&amp;Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stops</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Futures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Backtest Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter new backtest rule name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NewRule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qtstalker: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This backtest rule already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TesterChartPage</name>
    <message>
        <source>Scale To Screen</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TesterReport</name>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entry Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Balance </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Net Profit </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Net Profit % </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Initial Investment </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commissions </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Largest Drawdown </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trades </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Long Trades </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Short Trades </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Win Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profit </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Average </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Largest </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loss Summary</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TesterRulePage</name>
    <message>
        <source>Enter Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit Short</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TesterStopPage</name>
    <message>
        <source>Maximum Loss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loss %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profit %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trailing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Long Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Short Stop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TesterTestPage</name>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mid Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trade Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Futures Margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Commission %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bar Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entry/Exit Price</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Text</name>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select point to place Text...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrendLine</name>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extend Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bar Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit TrendLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select TrendLine starting point...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select TrendLine ending point...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpgradeMessage</name>
    <message>
        <source>This version of Qtstalker uses a new data format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> It can not read data files from previous versions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> This means that you will start with an empty workspace.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Your old data files have been preserved in $HOME/Qtstalker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> and can still be accessed by older Qtstalker versions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> If you don&apos;t intend to downgrade to a previous Qtstalker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> version, then you can remove that directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do not show this message again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chart Conversion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Perform Conversion</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VerticalLine</name>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit VerticalLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select point to place VerticalLine...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Yahoo</name>
    <message>
        <source>Timeout: retry limit skipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adjustment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Symbols</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No symbols selected. Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open db</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bad date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Yahoo Symbols</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter symbols to add. Note: separate symbols with a space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yahoo Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>skipped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Timeout: retry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to download</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
